package com.example.studentcard;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class StudentRun extends Application implements Initializable {

    public ListView Activities;
    @FXML
    public Circle face;
    @FXML
    private Label studentName;
    @FXML
    private Label studentNumber;
    @FXML
    private Button next;
    private int currentStudentIndex = 0;
    private Student[] students;


    /** Initializes the controller class. */
    @Override
    public void initialize(URL location, ResourceBundle resources) {

        Student student1 = new Student("images/face.jpeg","john", "doe", 324536363);
        student1.addFavouriteActivity("Basketball");
        student1.addFavouriteActivity("Chess");
        student1.addFavouriteActivity("Swimming");
        student1.addFavouriteActivity("Reading");
        student1.addFavouriteActivity("Writing");
        student1.addFavouriteActivity("Programming");
        student1.addFavouriteActivity("Playing Guitar");
        student1.addFavouriteActivity("Drawing");
        student1.addFavouriteActivity("Hiking");
        student1.addFavouriteActivity("Cooking");

        Student student2 = new Student("images/face-2.jpg","James", "Dustin", 987123456);
        student2.addFavouriteActivity("Gardening");
        student2.addFavouriteActivity("Yoga");
        student2.addFavouriteActivity("Meditation");
        student2.addFavouriteActivity("Running");
        student2.addFavouriteActivity("Cycling");
        student2.addFavouriteActivity("Playing Piano");
        student2.addFavouriteActivity("Singing");
        student2.addFavouriteActivity("Dancing");
        student2.addFavouriteActivity("Watching Movies");


        Student student3 = new Student("images/face-3.jpg","Brine", "Gordon", 327983223);
        student3.addFavouriteActivity("Soccer");
        student3.addFavouriteActivity("Swimming");
        student3.addFavouriteActivity("Hiking");
        student3.addFavouriteActivity("Painting");
        student3.addFavouriteActivity("Yoga");
        student3.addFavouriteActivity("Reading");
        student3.addFavouriteActivity("Writing");
        student3.addFavouriteActivity("Cooking");
        student3.addFavouriteActivity("Gaming");
        student3.addFavouriteActivity("Dancing");



        students = new Student[]{student1, student2, student3};
        setStudentInformation(students[currentStudentIndex]);

    }


    /** Sets the student information to be displayed on the UI. */
    private void setStudentInformation(Student student) {
        face.setFill(new ImagePattern(student.getImg()));
        studentName.setText(student.getFirstName() + " " + student.getLastName());
        studentNumber.setText(Integer.toString(student.getStudentNumber()));
        Activities.getItems().setAll(student.getFavouriteActivities());
    }

    /** Handles the button click to show the next student's information. */
    @FXML
    private void onNextButtonClick(ActionEvent event) {
        currentStudentIndex++;
        if (currentStudentIndex >= students.length) {
            currentStudentIndex = 0;
        }
        setStudentInformation(students[currentStudentIndex]);
    }

    /** Starts the JavaFX application and loads the FXML file for the GUI. */
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(StudentRun.class.getResource("Student.fxml"));
        Scene scene = new Scene(fxmlLoader.load());



        stage.setTitle("Georgian Portal");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}