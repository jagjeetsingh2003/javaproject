package com.example.studentcard;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;

import java.util.ArrayList;
import java.util.List;

public class Student {

    private String location = "images/face.jpeg";
    private String firstName;
    private String lastName;
    private int studentNumber;
    private List<String> favouriteActivities;

    @FXML
    Label studentName;



    /**
     * Constructor for creating a Student object with a specified profile image, first name, last name, and student number.
     *
     * @param location the location of the profile image
     * @param firstName the first name of the student
     * @param lastName the last name of the student
     * @param studentNumber the student number of the student
     */
    public Student(String location, String firstName, String lastName, int studentNumber) {
        this.location = location;
        setFirstName(firstName);
        setLastName(lastName);
        setStudentNumber(studentNumber);
        favouriteActivities = new ArrayList<String>();
    }


    /**
     * Sets the first name of the student.
     *
     * @param firstName the first name of the student
     * @throws IllegalArgumentException if the first name is null or less than 2 letters long
     */
    public void setFirstName(String firstName) {
        if (firstName == null || firstName.length() < 2) {
            throw new IllegalArgumentException("First name must be at least 2 letters long.");
        }
        firstName = firstName.substring(0, 1).toUpperCase() + firstName.substring(1);
        this.firstName = firstName;
    }


    /**
     * Sets the last name of the student.
     *
     * @param lastName the last name of the student
     * @throws IllegalArgumentException if the last name is null or less than 2 letters long
     */
    public void setLastName(String lastName) {
        if (lastName == null || lastName.length() < 2) {
            throw new IllegalArgumentException("Last name must be at least 2 letters long.");
        }
        lastName = lastName.substring(0, 1).toUpperCase() + lastName.substring(1);
        this.lastName = lastName;
    }


    /**
     * Sets the student number of the student.
     *
     * @param studentNumber the student number of the student
     * @throws IllegalArgumentException if the student number is not in the range of 010000000 -> 999999999
     */
    public void setStudentNumber(int studentNumber) {
        if (studentNumber < 100000000 || studentNumber > 999999999) {
            throw new IllegalArgumentException("Student number must be in the range of 010000000 -> 999999999.");
        }
        this.studentNumber = studentNumber;
    }


    /**
     * Adds a favorite activity to the list of favorite activities for the student.
     *
     * @param activity the name of the favorite activity to add
     */
    public void addFavouriteActivity(String activity) {
        favouriteActivities.add(activity);
    }


    /**
     * Returns the first name of the student.
     */
    public String getFirstName() {
        return firstName;
    }


    /**
     * Returns the last name of the student.
     */
    public String getLastName() {
        return lastName;
    }


    /**
     * Returns the Student Number of the student.
     */
    public int getStudentNumber() {
        return studentNumber;
    }


    /**
     * Returns the image using the location from student object
     */
    public Image getImg(){ return new Image(Student.class.getResourceAsStream(location)); }



    /**
     * Returns the list pf Favourite activities of the student.
     */
    public List<String> getFavouriteActivities() {
        return favouriteActivities;
    }

}
